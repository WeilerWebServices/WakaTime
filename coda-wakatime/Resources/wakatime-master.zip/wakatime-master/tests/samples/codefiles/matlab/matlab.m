function foo = bar(a, b, c)

% This is a variable
avariables = 0;

% =============================================================
% This is a Matlab comment
% =============================================================

end
