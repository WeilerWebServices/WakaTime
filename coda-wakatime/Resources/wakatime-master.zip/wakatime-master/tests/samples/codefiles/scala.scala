package com.wakatime.test

import com.alpha.SomeClass
import com.bravo.something.{User, UserPreferences}
import com.charlie.{Delta => Foxtrot}
import __root__.golf._
import com.hotel.india._
import juliett.kilo

object SimpleObject {
  def method(arg: String): String = {
    return "value"
  }
}
