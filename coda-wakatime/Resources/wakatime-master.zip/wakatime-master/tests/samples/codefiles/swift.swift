//
//  Swift.swift
//

import Foundation
import UIKit
import PromiseKit

class ViewController: UIViewController {

  private var attribute: URL?

  override func viewDidLoad() {
    // noop
  }
}
